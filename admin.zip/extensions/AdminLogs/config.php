<?php

return array(
    'actions'  => array(
        'activate'   => 'Extension\\AdminLogs\\AdminLogs@save',
        'deactivate' => '',
        'save'       => 'Extension\\AdminLogs\\AdminLogs@save',
    ),
);
