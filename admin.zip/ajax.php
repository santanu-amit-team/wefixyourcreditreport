<?php
require_once ('library' . DIRECTORY_SEPARATOR . 'bootstrap.php');

Bootstrap::initialize('ajax');