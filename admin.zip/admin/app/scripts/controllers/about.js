'use strict';

/**
 * @ngdoc function
 * @name codeBaseAdminApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the codeBaseAdminApp
 */
angular.module('codeBaseAdminApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
